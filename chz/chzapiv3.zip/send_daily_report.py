import smtplib
import json
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from logger_config import get_logger, log_exception
from token_utils import load_regions_mapping, get_tc_to_region_mapping, group_violations_by_region

# Set up logger
email_logger = get_logger("email")

def load_email_config():
    """Load email configuration"""
    try:
        with open('email_config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
            email_logger.info("Email configuration loaded successfully")
            return config
    except Exception as e:
        log_exception(email_logger, e, "Error loading email config")
        return None

def send_region_violations_report(region_name: str, region_data: dict, email_config: dict) -> bool:
    """Send email with violations report for a region
    
    Args:
        region_name: Name of the region
        region_data: Dictionary with violation data for the region
        email_config: Email configuration dictionary
        
    Returns:
        bool: True if email was sent successfully, False otherwise
    """
    try:
        date = region_data["date"]
        email_logger.info(f"Preparing email report for region {region_name} on {date}")
        
        # Create HTML content with region header
        html = f"""
        <h2>Отчет о нарушениях маркировки за {date} - Регион: {region_name}</h2>
        <p>Общее количество нарушений в регионе: <b>{region_data['total_violations']}</b></p>
        """
        
        # Add data for each TC in the region
        for tc, tc_data in region_data["tc_data"].items():
            html += f"""
            <h3>Торговая сеть: {tc}</h3>
            <table border="1" style="border-collapse: collapse; width: 100%;">
                <tr style="background-color: #f2f2f2;">
                    <th style="padding: 8px;">Товарная группа</th>
                    <th style="padding: 8px;">Количество нарушений</th>
                </tr>
            """
            
            tc_total = 0
            for group, count in tc_data.get('violations', {}).items():
                tc_total += count
                html += f"""
                <tr>
                    <td style="padding: 8px;">{group}</td>
                    <td style="padding: 8px; text-align: center;">{count}</td>
                </tr>
                """
            
            html += f"""
                <tr style="background-color: #f2f2f2; font-weight: bold;">
                    <td style="padding: 8px;">Всего нарушений:</td>
                    <td style="padding: 8px; text-align: center;">{tc_total}</td>
                </tr>
            </table>
            <br>
            """
        
        # Create message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"Отчет о нарушениях маркировки - Регион: {region_name} - {date}"
        msg['From'] = email_config['sender_email']
        recipients = email_config['recipient_emails']
        msg['To'] = ', '.join(recipients)
        msg.attach(MIMEText(html, 'html'))
        
        email_logger.info(f"Sending email to {len(recipients)} recipients")
        
        # Send email
        with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
            server.starttls()
            server.login(email_config['sender_email'], email_config['sender_password'])
            server.send_message(msg)
            
        email_logger.info(f"Email report sent successfully for region {region_name}")
        return True
        
    except Exception as e:
        log_exception(email_logger, e, f"Error sending email report for region {region_name}")
        return False

def send_consolidated_reports(all_violations_data, email_config=None):
    """
    Send consolidated reports by region
    
    Args:
        all_violations_data: Dictionary mapping TC names to their violation data
        email_config: Email configuration (will be loaded if not provided)
    
    Returns:
        bool: True if all emails were sent successfully, False otherwise
    """
    if not email_config:
        email_config = load_email_config()
        if not email_config:
            email_logger.error("Failed to load email configuration")
            return False
    
    # Group violations by region
    region_violations = group_violations_by_region(all_violations_data)
    
    # Send email for each region
    success = True
    for region, region_data in region_violations.items():
        if region_data["tc_data"]:  # Only send if there's data
            result = send_region_violations_report(region, region_data, email_config)
            if not result:
                success = False
                email_logger.error(f"Failed to send email for region {region}")
    
    return success

def process_and_send_reports():
    """
    Process all violation reports and send consolidated emails by region
    """
    email_logger.info("Starting process_and_send_reports")
    
    email_config = load_email_config()
    if not email_config:
        email_logger.error("Failed to load email configuration")
        return False
        
    # Find all violation reports
    base_dir = 'output'
    all_violations = {}
    
    if not os.path.exists(base_dir):
        email_logger.warning("Output directory not found")
        return False
        
    # Collect all violation data
    for cert_dir in os.listdir(base_dir):
        cert_path = os.path.join(base_dir, cert_dir)
        if not os.path.isdir(cert_path):
            continue
            
        # Parse certificate name to extract TC name (assuming format "Name - TC")
        if " - " in cert_dir:
            tc_name = cert_dir.split(" - ")[1].strip()
        else:
            tc_name = cert_dir.strip()
            
        # Find the violation report JSON files
        json_files = [f for f in os.listdir(cert_path) if f.startswith('violations_') and f.endswith('.json')]
        if not json_files:
            continue
            
        # Use the most recent report
        json_file = sorted(json_files)[-1]
        json_path = os.path.join(cert_path, json_file)
        
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                violations_data = json.load(f)
                all_violations[tc_name] = violations_data
                email_logger.info(f"Loaded violations data for {tc_name}")
        except Exception as e:
            log_exception(email_logger, e, f"Error loading violations data for {tc_name}")
    
    if not all_violations:
        email_logger.warning("No violation data found")
        return False
        
    # Send consolidated reports by region
    result = send_consolidated_reports(all_violations, email_config)
    
    # Save the last run time
    try:
        with open('last_email_run.json', 'w', encoding='utf-8') as f:
            json.dump({"last_run": datetime.now().isoformat()}, f)
    except Exception as e:
        log_exception(email_logger, e, "Error saving last email run time")
    
    return result

if __name__ == "__main__":
    process_and_send_reports()
