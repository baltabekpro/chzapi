import os
import json
import smtplib
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from typing import Dict, Any

def load_email_config() -> Dict[str, Any]:
    """Load email configuration"""
    try:
        with open('email_config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
            required_fields = ['smtp_server', 'smtp_port', 'sender_email', 
                             'sender_password', 'recipient_emails']
            
            # Validate required fields
            for field in required_fields:
                if not config.get(field):
                    raise ValueError(f"Missing required field: {field}")
            
            print("Successfully loaded email config")
            return config
    except Exception as e:
        print(f"Error loading email config: {e}")
        return None

def send_violations_report(cert_name: str, violations_data: dict, email_config: dict) -> bool:
    """Send email with violations report"""
    try:
        # Create HTML content
        html = f"""
        <h2>Отчет о нарушениях маркировки за {violations_data['date']}</h2>
        <h3>Сертификат: {cert_name}</h3>
        <table border="1" style="border-collapse: collapse; width: 100%;">
            <tr style="background-color: #f2f2f2;">
                <th style="padding: 8px;">Товарная группа</th>
                <th style="padding: 8px;">Количество нарушений</th>
            </tr>
        """
        
        total_violations = 0
        for group, count in violations_data['violations'].items():
            total_violations += count
            html += f"""
            <tr>
                <td style="padding: 8px;">{group}</td>
                <td style="padding: 8px; text-align: center;">{count}</td>
            </tr>
            """
        
        html += f"""
            <tr style="background-color: #f2f2f2; font-weight: bold;">
                <td style="padding: 8px;">Всего нарушений:</td>
                <td style="padding: 8px; text-align: center;">{total_violations}</td>
            </tr>
        </table>
        """
        
        # Create message
        msg = MIMEMultipart()
        msg['Subject'] = f"Отчет о нарушениях маркировки - {cert_name} - {violations_data['date']}"
        msg['From'] = email_config['sender_email']
        msg['To'] = ', '.join(email_config['recipient_emails'])
        msg.attach(MIMEText(html, 'html', 'utf-8'))
        
        # Send email
        with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
            server.starttls()
            server.login(email_config['sender_email'], email_config['sender_password'])
            server.send_message(msg)
            
        print(f"Email report sent for {cert_name}")
        return True
        
    except Exception as e:
        print(f"Error sending email report: {e}")
        return False

def process_daily_reports():
    """Process and send daily violation reports"""
    base_dir = 'output'
    today = datetime.now().strftime('%Y-%m-%d')
    
    # Load email configuration
    email_config = load_email_config()
    if not email_config:
        print("Failed to load email configuration")
        return
    
    print("\nProcessing reports for", today)
    
    # Process each certificate's directory
    for cert_dir in os.listdir(base_dir):
        cert_path = os.path.join(base_dir, cert_dir)
        if not os.path.isdir(cert_path):
            continue
            
        report_file = os.path.join(cert_path, f'violations_{today}.json')
        print(f"\nChecking report for {cert_dir}")
        print(f"Looking for file: {report_file}")
        
        if not os.path.exists(report_file):
            print(f"No report found for {cert_dir} on {today}")
            continue
            
        try:
            print(f"Reading report file: {report_file}")
            with open(report_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            print(f"Sending report for {cert_dir}")
            if send_violations_report(cert_dir, data, email_config):
                print(f"Report sent for {cert_dir}")
            else:
                print(f"Failed to send report for {cert_dir}")
                
        except Exception as e:
            print(f"Error processing report for {cert_dir}: {e}")

def main():
    print("=== Daily Report Sender ===")
    process_daily_reports()

if __name__ == "__main__":
    main()
