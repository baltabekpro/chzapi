import os
import re
import json
from datetime import datetime
from get_violations import PRODUCT_GROUPS
from logger_config import get_logger, log_exception
from email_utils import send_violations_report, load_email_config

# Set up logger
reports_logger = get_logger("reports")

def read_csv_with_encoding(file_path: str) -> int:
    """Read CSV file and return number of violations"""
    encodings = ['cp1251', 'utf-8-sig', 'utf-8', 'windows-1251', 'latin1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                # Read all lines first
                lines = f.readlines()
                
                # Skip empty file
                if not lines:
                    return 0
                    
                # Find header line
                header = None
                for line in lines:
                    if line.strip():
                        header = line
                        break
                
                if not header:
                    return 0
                
                # Count non-empty lines after header
                count = sum(1 for line in lines if line.strip() and line != header)
                reports_logger.info(f"Successfully read file with {encoding} encoding, found {count} violations")
                return count
                
        except UnicodeDecodeError:
            continue
        except Exception as e:
            reports_logger.warning(f"Error with {encoding} encoding: {e}")
            continue
    
    reports_logger.error(f"Could not read file {file_path} with any encoding")
    return 0

def process_reports_for_token(cert_name: str, email_config: dict = None):
    """Process all reports into single JSON file and send email
    
    Args:
        cert_name: Certificate name/ID
        email_config: Email configuration dictionary (optional)
    """
    reports_logger.info(f"Processing reports for certificate: {cert_name}")
    
    # Load email config if not provided
    if email_config is None:
        email_config = load_email_config()
    
    base_dir = os.path.join('output', cert_name)
    reports_dir = os.path.join(base_dir, 'reports')
    
    if not os.path.exists(reports_dir):
        reports_logger.warning("No reports directory found")
        return
        
    today = datetime.now().strftime('%Y-%m-%d')
    violations_data = {
        'date': today,
        'violations': {}
    }
    
    csv_files = [f for f in os.listdir(reports_dir) if f.endswith('.csv')]
    reports_logger.info(f"Found {len(csv_files)} CSV files to process")
    
    for csv_file in csv_files:
        try:
            input_path = os.path.join(reports_dir, csv_file)
            reports_logger.info(f"Processing file: {csv_file}")
            
            # Extract group code from filename using improved parsing
            # Example filename: violations_group1__20250303_235139.csv
            group_code = None
            try:
                # Find the number after 'group' in the filename
                match = re.search(r'group(\d+)', csv_file)
                if match:
                    group_code = int(match.group(1))
            except ValueError:
                reports_logger.warning(f"Could not extract group code from filename: {csv_file}")
                continue
            
            if group_code is None:
                reports_logger.warning(f"No group code found in filename: {csv_file}")
                continue
            
            # Get product group name
            product_name = PRODUCT_GROUPS.get(group_code)
            if not product_name:
                reports_logger.warning(f"Unknown product group code: {group_code}")
                continue
                
            violation_count = read_csv_with_encoding(input_path)
            violations_data['violations'][product_name] = violation_count
            reports_logger.info(f"Found {violation_count} violations for {product_name}")
            
            os.remove(input_path)
            reports_logger.info(f"Processed and removed {csv_file}")
            
        except Exception as e:
            log_exception(reports_logger, e, f"Error processing {csv_file}")
    
    # Save consolidated JSON
    if violations_data['violations']:
        output_file = os.path.join(base_dir, f'violations_{today}.json')
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(violations_data, f, ensure_ascii=False, indent=2)
        reports_logger.info(f"Saved consolidated data to {output_file}")
        
        # Send email report
        if email_config:
            email_result = send_violations_report(cert_name, violations_data, email_config)
            reports_logger.info(f"Email sending {'succeeded' if email_result else 'failed'}")
        else:
            reports_logger.warning("No email configuration available, skipping email notification")
            
        return violations_data
    else:
        reports_logger.warning("No violation data found")
        return None

def view_report(report_path: str):
    """View and display report information
    
    Args:
        report_path: Path to the report JSON file
    """
    if not os.path.exists(report_path):
        print(f"Report not found: {report_path}")
        return
    
    try:
        with open(report_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            date = data.get('date', 'Неизвестная дата')
            
            print(f"\n=== Отчет о нарушениях за {date} ===")
            cert_name = os.path.basename(os.path.dirname(report_path))
            print(f"Сертификат: {cert_name}")
            
            print("\nНарушения по товарным группам:")
            total = 0
            for group, count in data.get('violations', {}).items():
                total += count
                print(f"- {group}: {count}")
            
            print(f"\nВсего нарушений: {total}")
            return data
            
    except Exception as e:
        print(f"Ошибка чтения отчета: {e}")
        reports_logger.error(f"Error reading report {report_path}: {e}")
        return None

if __name__ == "__main__":
    # If run directly, process a report
    import sys
    if len(sys.argv) > 1:
        cert_name = sys.argv[1]
        print(f"Processing reports for certificate: {cert_name}")
        result = process_reports_for_token(cert_name)
        if result:
            print("Report processing completed successfully")
        else:
            print("Failed to process reports")
    else:
        print("Usage: python report_processor.py <certificate_name>")
