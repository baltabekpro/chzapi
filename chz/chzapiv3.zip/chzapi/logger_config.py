import os
import logging
from datetime import datetime
from logging.handlers import RotatingFileHandler

# Create logs directory if it doesn't exist
logs_dir = os.path.join(os.getcwd(), "logs")
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

def setup_logger(name=None, log_level=logging.INFO):
    """
    Configure and return a logger that logs to both console and file
    
    Args:
        name: Logger name (defaults to root logger if None)
        log_level: Logging level (INFO by default)
        
    Returns:
        Configured logger instance
    """
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(log_level)
    logger.handlers = []  # Clear any existing handlers
    
    # Log format with timestamps
    log_format = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_format)
    logger.addHandler(console_handler)
    
    # File handler (automatic rotation, max 10MB, keep 10 backup files)
    if name is None:
        log_filename = "app.log"
    else:
        log_filename = f"{name}.log"
        
    file_handler = RotatingFileHandler(
        os.path.join(logs_dir, log_filename),
        maxBytes=10*1024*1024,  # 10MB
        backupCount=10,
        encoding='utf-8'
    )
    file_handler.setFormatter(log_format)
    logger.addHandler(file_handler)
    
    return logger

def get_logger(name=None):
    """Get a configured logger instance"""
    return setup_logger(name)

def log_exception(logger, exc, additional_info=None):
    """
    Log an exception with detailed information
    
    Args:
        logger: Logger instance
        exc: Exception object
        additional_info: Optional additional context information
    """
    import traceback
    
    if additional_info:
        logger.error(f"{additional_info}: {type(exc).__name__}: {str(exc)}")
    else:
        logger.error(f"Exception: {type(exc).__name__}: {str(exc)}")
        
    # Log traceback
    logger.error(f"Traceback: {traceback.format_exc()}")
