import zipfile
import csv
import sys
import os
import json
from datetime import datetime
from collections import defaultdict
import pandas as pd
from typing import List, Dict, Any
import chardet

def detect_encoding(file_path: str) -> str:
    """
    Определяет кодировку файла
    """
    with open(file_path, 'rb') as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        return result['encoding']

def process_violations_report(zip_file_path: str) -> None:
    """Обрабатывает ZIP-файл с отчетом о нарушениях и сохраняет результаты в JSON"""
    extract_dir = "report_" + datetime.now().strftime('%Y%m%d_%H%M%S')
    os.makedirs(extract_dir, exist_ok=True)
    
    try:
        # Распаковываем архив
        print(f"Распаковка {zip_file_path}...")
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        
        # Ищем CSV файл
        csv_files = [f for f in os.listdir(extract_dir) if f.endswith('.csv')]
        if not csv_files:
            print("CSV файл не найден в архиве")
            return
        
        csv_file = os.path.join(extract_dir, csv_files[0])
        print(f"Найден файл: {csv_files[0]}")
        
        # Подготавливаем структуру для JSON
        result = {
            "meta": {
                "generated": datetime.now().isoformat(),
                "source_file": zip_file_path,
                "report_date": datetime.now().strftime('%Y-%m-%d')
            },
            "statistics": defaultdict(int),
            "violations": []
        }
        
        # Читаем и анализируем CSV
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Очищаем пустые значения
                violation = {k: v for k, v in row.items() if v}
                result["violations"].append(violation)
                
                # Собираем статистику
                result["statistics"]["total"] += 1
                result["statistics"][violation.get("Вид отклонения", "Неизвестно")] += 1
                if violation.get("Товарная группа"):
                    result["statistics"][f"Группа_{violation['Товарная группа']}"] += 1
        
        # Добавляем дополнительную статистику
        result["statistics"] = dict(result["statistics"])  # Converting defaultdict to dict
        
        # Сохраняем результаты в JSON файлы
        base_name = os.path.splitext(os.path.basename(zip_file_path))[0]
        
        # Полный отчет
        full_report_path = os.path.join(extract_dir, f"{base_name}_full.json")
        with open(full_report_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"\nПолный отчет сохранен в: {full_report_path}")
        
        # Только статистика
        stats_path = os.path.join(extract_dir, f"{base_name}_stats.json")
        with open(stats_path, 'w', encoding='utf-8') as f:
            json.dump({"meta": result["meta"], "statistics": result["statistics"]}, 
                     f, ensure_ascii=False, indent=2)
        print(f"Статистика сохранена в: {stats_path}")
        
        # Краткая сводка в консоль
        print("\nКраткая статистика:")
        print(f"Всего нарушений: {result['statistics']['total']}")
        print("\nПо видам отклонений:")
        for key, value in result["statistics"].items():
            if key != "total" and not key.startswith("Группа_"):
                print(f"- {key}: {value}")
        
    except Exception as e:
        print(f"Ошибка при обработке файла: {e}")
        sys.exit(1)

def try_read_file_with_encodings(file_path: str) -> tuple[pd.DataFrame, str, str]:
    """
    Пытается прочитать файл с разными кодировками и разделителями
    
    Returns:
        tuple[DataFrame, encoding, separator]
    """
    encodings = ['cp1251', 'utf-8', 'windows-1251', 'ascii', 'iso-8859-1']
    separators = [';', ',', '\t', '|']
    errors = []

    # Сначала пробуем определить кодировку через chardet
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            detected = chardet.detect(raw_data)
            if detected and detected['encoding']:
                encodings.insert(0, detected['encoding'])
    except Exception as e:
        print(f"Ошибка при определении кодировки: {e}")

    # Пробуем все комбинации кодировок и разделителей
    for encoding in encodings:
        for sep in separators:
            try:
                df = pd.read_csv(
                    file_path,
                    encoding=encoding,
                    sep=sep,
                    on_bad_lines='skip',
                    low_memory=False,
                    dtype=str
                )
                
                # Проверяем, что файл прочитан корректно
                if len(df.columns) > 1 and len(df) > 0:
                    print(f"Успешно прочитан с кодировкой {encoding} и разделителем '{sep}'")
                    return df, encoding, sep
                    
            except Exception as e:
                errors.append(f"[{encoding}, {sep}]: {str(e)}")
                continue
    
    # Если все попытки не удались, пробуем прочитать как текстовый файл
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                first_lines = [next(f) for _ in range(5)]
                print("\nПервые 5 строк файла:")
                for line in first_lines:
                    print(line.strip())
        except Exception:
            continue

    raise ValueError(f"Не удалось прочитать файл. Попробованные варианты:\n" + "\n".join(errors))

def process_reports(input_path: str) -> list:
    """
    Process CSV file and return list of dictionaries
    
    Args:
        input_path: Path to input CSV file
    Returns:
        List of dictionaries containing the processed data
    """
    temp_dir = None
    try:
        print(f"Обработка файла: {input_path}")
        
        # Создаем директории
        reports_dir = 'reports'
        json_dir = os.path.join(reports_dir, 'json')
        temp_dir = os.path.join(reports_dir, f"temp_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        
        os.makedirs(reports_dir, exist_ok=True)
        os.makedirs(json_dir, exist_ok=True)
        os.makedirs(temp_dir, exist_ok=True)

        # Проверяем, является ли файл ZIP-архивом
        is_zip = False
        try:
            with zipfile.ZipFile(input_path, 'r') as zip_ref:
                print("Обнаружен ZIP файл, распаковываем...")
                zip_ref.extractall(temp_dir)
                is_zip = True
        except zipfile.BadZipFile:
            print("Файл не является ZIP архивом, обрабатываем как CSV")
            
        # Если это был ZIP, ищем CSV файл внутри распакованной директории
        if is_zip:
            csv_files = [f for f in os.listdir(temp_dir) if f.endswith('.csv')]
            if not csv_files:
                raise ValueError("CSV файл не найден в ZIP архиве")
            input_path = os.path.join(temp_dir, csv_files[0])
            print(f"Найден CSV файл: {csv_files[0]}")

        # Пытаемся прочитать файл с разными кодировками
        encodings = ['cp1251', 'utf-8', 'windows-1251', 'ascii', 'iso-8859-1']
        separators = [';', ',', '\t', '|']
        df = None
        used_encoding = None
        used_separator = None

        for encoding in encodings:
            if df is not None:
                break
            for sep in separators:
                try:
                    df = pd.read_csv(
                        input_path,
                        encoding=encoding,
                        sep=sep,
                        on_bad_lines='skip',
                        low_memory=False,
                        dtype=str
                    )
                    if len(df.columns) > 1 and len(df) > 0:
                        used_encoding = encoding
                        used_separator = sep
                        print(f"Успешно прочитан с кодировкой {encoding} и разделителем '{sep}'")
                        break
                except Exception:
                    continue

        if df is None:
            raise ValueError("Не удалось прочитать файл ни с одной из кодировок")

        # Очищаем данные
        df = df.fillna('')

        # Конвертируем DataFrame в список словарей
        records = []
        for _, row in df.iterrows():
            record = {k.strip(): v.strip() if isinstance(v, str) else v 
                     for k, v in row.items() 
                     if pd.notna(v) and str(v).strip()}
            records.append(record)

        # Создаем структуру JSON
        result = {
            "meta": {
                "filename": os.path.basename(input_path),
                "records_count": len(records),
                "processed_at": datetime.now().isoformat(),
                "encoding_used": used_encoding,
                "separator_used": used_separator,
                "original_file": os.path.basename(input_path)
            },
            "violations": records
        }

        print(f"Обработано записей: {len(records)}")

        # Удаляем исходный файл только если он находится в директории reports
        if os.path.dirname(os.path.abspath(input_path)).startswith(os.path.abspath(reports_dir)):
            os.remove(input_path)
            print(f"Исходный файл удален: {input_path}")

        return result

    except Exception as e:
        print(f"Ошибка при обработке файла {input_path}: {e}")
        return None
        
    finally:
        # Очищаем временную директорию
        if temp_dir and os.path.exists(temp_dir):
            import shutil
            shutil.rmtree(temp_dir)

def process_multiple_reports(input_files: List[str], output_dir: str = None) -> Dict[str, Any]:
    """
    Обрабатывает несколько CSV файлов и объединяет их в один JSON
    
    Args:
        input_files: Список путей к CSV файлам
        output_dir: Директория для сохранения результата (если None, используется reports/json)
    Returns:
        Dict с результатами обработки
    """
    # Создаем директории если не указан output_dir
    if output_dir is None:
        output_dir = os.path.join('reports', 'json')
    
    os.makedirs(output_dir, exist_ok=True)
    
    all_records = []
    results = {
        "processed_files": 0,
        "total_records": 0,
        "output_file": "",
        "errors": []
    }
    
    try:
        for file in input_files:
            try:
                df = pd.read_csv(file, encoding='utf-8', sep=';')
                records = df.to_dict('records')
                all_records.extend(records)
                results["processed_files"] += 1
                results["total_records"] += len(records)
            except Exception as e:
                results["errors"].append(f"Ошибка при обработке {file}: {str(e)}")
        
        if all_records:
            # Создаем итоговый JSON
            output_file = os.path.join(output_dir, "combined_violations.json")
            os.makedirs(output_dir, exist_ok=True)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "total": len(all_records),
                    "violations": all_records
                }, f, ensure_ascii=False, indent=2)
            
            results["output_file"] = output_file
            
    except Exception as e:
        results["errors"].append(f"Общая ошибка: {str(e)}")
    
    return results

def main():
    """Main function"""
    # Создаем базовую структуру директорий
    reports_dir = 'reports'
    json_dir = os.path.join(reports_dir, 'json')
    os.makedirs(reports_dir, exist_ok=True)
    os.makedirs(json_dir, exist_ok=True)

    # Ищем CSV файлы в директории reports
    csv_files = [f for f in os.listdir(reports_dir) if f.endswith('.csv')]
    if not csv_files:
        print("CSV файлы не найдены в директории reports")
        sys.exit(1)
    
    for csv_file in csv_files:
        input_path = os.path.join(reports_dir, csv_file)
        output_path = os.path.join(json_dir, csv_file.replace('.csv', '.json'))
        
        print(f"Обработка файла: {csv_file}")
        result = process_reports(input_path)
        if result:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"Файл успешно конвертирован в JSON: {output_path}")
        else:
            print(f"Ошибка при конвертации файла: {csv_file}")

if __name__ == "__main__":
    main()
