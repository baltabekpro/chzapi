"""
Utility functions for token management
"""

import os
import json
import datetime
import jwt
from typing import Dict, List, Tuple, Optional, Any
import colorama
from colorama import Fore

# Initialize colorama
colorama.init(autoreset=True)

def load_tokens() -> Dict[str, str]:
    """Load tokens from the token file"""
    try:
        if not os.path.exists('true_api_tokens.json'):
            return {}
            
        with open('true_api_tokens.json', 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('tokens', {})
    except Exception as e:
        print(f"Error loading tokens: {e}")
        return {}

def get_any_valid_token() -> Optional[str]:
    """Get any valid token from the token file"""
    tokens = load_tokens()
    
    if not tokens:
        return None
    
    # Try each token until we find a valid one
    for name, token in tokens.items():
        if is_token_valid(token):
            print(f"Using token for: {name}")
            return token
    
    print("No valid tokens found")
    return None

def get_token_for_tc(tc: str) -> Optional[str]:
    """Get token for specific ТС"""
    tokens = load_tokens()
    
    if not tokens:
        return None
    
    # Look for tokens with ТС in their name
    for name, token in tokens.items():
        if f" - {tc}" in name and is_token_valid(token):
            print(f"Found valid token for ТС {tc}")
            return token
    
    print(f"No valid token found for ТС {tc}")
    return None

def is_token_valid(token: str) -> bool:
    """Check if token is valid and not expired"""
    try:
        # Decode without verification to check expiration
        decoded = jwt.decode(token, options={"verify_signature": False})
        
        # Check expiration
        if 'exp' in decoded:
            expiration = datetime.datetime.fromtimestamp(decoded['exp'])
            now = datetime.datetime.now()
            
            if expiration > now:
                return True
        
        return False
    except Exception:
        return False

def get_token_info(token: str) -> Dict[str, Any]:
    """Get information from token"""
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        
        # Extract basic info
        info = {
            "user": decoded.get('full_name', 'Unknown'),
            "inn": decoded.get('inn', 'Unknown'),
            "organization_status": decoded.get('organisation_status', 'Unknown'),
            "product_groups": [],
            "expires_at": datetime.datetime.fromtimestamp(decoded.get('exp', 0)).strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Extract product group info if available
        if 'product_group_info' in decoded:
            for group in decoded['product_group_info']:
                info["product_groups"].append({
                    "name": group.get('name', 'Unknown'),
                    "status": group.get('status', 'Unknown'),
                    "types": group.get('types', [])
                })
        
        return info
    except Exception as e:
        print(f"{Fore.RED}Error extracting token info: {str(e)}")
        return None

def update_token(cert_name, token):
    """
    Update a specific token in the JSON file
    """
    try:
        tokens = {}
        if os.path.exists('true_api_tokens.json'):
            with open('true_api_tokens.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                tokens = data.get('tokens', {})
        
        tokens[cert_name] = token
        
        with open('true_api_tokens.json', 'w', encoding='utf-8') as f:
            json.dump(
                {
                    "tokens": tokens,
                    "generated_at": datetime.datetime.now().isoformat()
                }, 
                f, 
                indent=2,
                ensure_ascii=False
            )
        return True
    except Exception as e:
        print(f"{Fore.RED}Error updating token: {str(e)}")
        return False

def display_all_tokens_info():
    """
    Display information about all available tokens.
    """
    try:
        if os.path.exists('true_api_tokens.json'):
            with open('true_api_tokens.json', 'r', encoding='utf-8') as f:
                tokens_data = json.load(f)
                tokens = tokens_data.get('tokens', {})
                
            if not tokens:
                print(f"{Fore.YELLOW}No tokens found in token file.")
                return
                
            print(f"\n{Fore.CYAN}=== Available Tokens ===")
            for i, (cert_name, token) in enumerate(tokens.items(), 1):
                print(f"\n{Fore.CYAN}Token {i}: {cert_name}")
                
                # Check validity
                is_valid = is_token_valid(token)
                status = f"{Fore.GREEN}VALID" if is_valid else f"{Fore.RED}EXPIRED"
                print(f"Status: {status}")
                
                # Get token info
                info = get_token_info(token)
                if info:
                    print(f"User: {info['user']}")
                    print(f"INN: {info['inn']}")
                    print(f"Expires: {info['expires_at']}")
                    
                    if info['product_groups']:
                        print("Product groups:")
                        for group in info['product_groups'][:5]:  # Show first 5 groups
                            print(f"  - {group['name']}")
                        if len(info['product_groups']) > 5:
                            print(f"  - ... and {len(info['product_groups'])-5} more")
        else:
            print(f"{Fore.YELLOW}Token file not found.")
                
    except Exception as e:
        print(f"{Fore.RED}Error displaying token info: {str(e)}")

if __name__ == "__main__":
    # When run directly, display info about all tokens
    token = get_any_valid_token()
    if token:
        print(f"\n{Fore.GREEN}Found valid token!")
        info = get_token_info(token)
        if info:
            print(f"\n{Fore.CYAN}Token Information:")
            print(f"User: {info['user']}")
            print(f"INN: {info['inn']}")
            print(f"Expires: {info['expires_at']}")
            print(f"Product Groups: {len(info['product_groups'])}")
    else:
        print(f"\n{Fore.RED}No valid tokens found.")
