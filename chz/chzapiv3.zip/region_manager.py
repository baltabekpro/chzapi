"""
Region Management Module

This module provides functionality for managing regions and their TC assignments.
"""
import os
import json
import sys
import colorama
from colorama import Fore, Style
from logger_config import get_logger, log_exception

# Initialize colorama
colorama.init(autoreset=True)

# Set up logger
region_logger = get_logger("regions")

def load_regions():
    """Load regions from regions.json file"""
    try:
        if not os.path.exists('regions.json'):
            # Create empty regions file if it doesn't exist
            with open('regions.json', 'w', encoding='utf-8') as f:
                json.dump({}, f, ensure_ascii=False, indent=2)
            region_logger.info("Created new regions.json file")
            return {}
            
        with open('regions.json', 'r', encoding='utf-8') as f:
            regions = json.load(f)
            region_logger.info(f"Loaded {len(regions)} regions from regions.json")
            return regions
    except Exception as e:
        log_exception(region_logger, e, "Error loading regions.json")
        return {}

def save_regions(regions):
    """Save regions to regions.json file"""
    try:
        with open('regions.json', 'w', encoding='utf-8') as f:
            json.dump(regions, f, ensure_ascii=False, indent=2)
        region_logger.info(f"Saved {len(regions)} regions to regions.json")
        return True
    except Exception as e:
        log_exception(region_logger, e, "Error saving regions.json")
        return False

def list_regions():
    """List all existing regions and their TCs"""
    regions = load_regions()
    
    if not regions:
        print(f"{Fore.YELLOW}No regions defined. Use 'Add Region' option to create regions.")
        return
        
    print(f"\n{Fore.CYAN}╔══════════ Defined Regions ══════════╗")
    
    for i, (region_name, tcs) in enumerate(regions.items(), 1):
        print(f"{Fore.CYAN}║ {i:<2}. {region_name}")
        print(f"{Fore.CYAN}║    TCs ({len(tcs)}): ", end="")
        if tcs:
            tc_list = ", ".join(tcs)
            if len(tc_list) > 50:
                # Truncate if too long
                print(f"{tc_list[:47]}...")
            else:
                print(tc_list)
        else:
            print(f"{Fore.YELLOW}No TCs assigned")
        print(f"{Fore.CYAN}║")
    
    print(f"{Fore.CYAN}╚══════════════════════════════════╝")

def view_region_details(region_name=None):
    """View detailed information about a specific region"""
    regions = load_regions()
    
    if not regions:
        print(f"{Fore.YELLOW}No regions defined.")
        return
    
    # If region not specified, prompt user to select one
    if not region_name:
        list_regions()
        selected = input(f"\n{Fore.YELLOW}Enter region number or name (0 to cancel): ")
        
        try:
            if selected == "0":
                return
                
            # Check if input is a number
            if selected.isdigit():
                idx = int(selected) - 1
                if 0 <= idx < len(regions):
                    region_name = list(regions.keys())[idx]
                else:
                    print(f"{Fore.RED}Invalid region number.")
                    return
            else:
                # Check if input is a region name
                if selected in regions:
                    region_name = selected
                else:
                    print(f"{Fore.RED}Region '{selected}' not found.")
                    return
        except Exception as e:
            print(f"{Fore.RED}Error selecting region: {e}")
            return
    
    # Display region details
    if region_name not in regions:
        print(f"{Fore.RED}Region '{region_name}' not found.")
        return
        
    tcs = regions[region_name]
    
    print(f"\n{Fore.CYAN}╔══════════ Region Details ══════════╗")
    print(f"{Fore.CYAN}║ Name: {Fore.WHITE}{region_name}")
    print(f"{Fore.CYAN}║ Number of TCs: {Fore.WHITE}{len(tcs)}")
    print(f"{Fore.CYAN}║")
    print(f"{Fore.CYAN}║ {Fore.YELLOW}Assigned TCs:")
    
    if tcs:
        for i, tc in enumerate(tcs, 1):
            print(f"{Fore.CYAN}║ {i:<3}. {Fore.WHITE}{tc}")
    else:
        print(f"{Fore.CYAN}║ {Fore.YELLOW}No TCs assigned to this region")
    
    print(f"{Fore.CYAN}╚══════════════════════════════════╝")

def add_region():
    """Add a new region"""
    regions = load_regions()
    
    # Get region name
    while True:
        name = input(f"\n{Fore.YELLOW}Enter new region name: ").strip()
        
        if not name:
            print(f"{Fore.RED}Region name cannot be empty.")
            continue
            
        if name in regions:
            print(f"{Fore.RED}Region '{name}' already exists.")
            continue
            
        break
    
    # Add new region with empty TC list
    regions[name] = []
    if save_regions(regions):
        print(f"{Fore.GREEN}Region '{name}' added successfully.")
        region_logger.info(f"Added new region: {name}")
        
        # Ask if user wants to add TCs to this region
        add_tcs = input(f"\n{Fore.YELLOW}Do you want to add TCs to this region now? (y/n): ").lower()
        if add_tcs == 'y':
            add_tc_to_region(name)
    else:
        print(f"{Fore.RED}Failed to save new region.")

def add_tc_to_region(region_name=None):
    """Add TC to a region"""
    regions = load_regions()
    
    if not regions:
        print(f"{Fore.YELLOW}No regions defined. Create a region first.")
        return
    
    # If region not specified, prompt user to select one
    if not region_name:
        list_regions()
        selected = input(f"\n{Fore.YELLOW}Enter region number or name (0 to cancel): ")
        
        try:
            if selected == "0":
                return
                
            # Check if input is a number
            if selected.isdigit():
                idx = int(selected) - 1
                if 0 <= idx < len(regions):
                    region_name = list(regions.keys())[idx]
                else:
                    print(f"{Fore.RED}Invalid region number.")
                    return
            else:
                # Check if input is a region name
                if selected in regions:
                    region_name = selected
                else:
                    print(f"{Fore.RED}Region '{selected}' not found.")
                    return
        except Exception as e:
            print(f"{Fore.RED}Error selecting region: {e}")
            return
    
    # Check if region exists
    if region_name not in regions:
        print(f"{Fore.RED}Region '{region_name}' not found.")
        return
    
    # Get TC name
    print(f"{Fore.CYAN}Adding TC to region '{region_name}'")
    print(f"{Fore.CYAN}Current TCs: {', '.join(regions[region_name]) if regions[region_name] else 'None'}")
    
    # Allow adding multiple TCs
    while True:
        tc_name = input(f"\n{Fore.YELLOW}Enter TC name (or empty to finish): ").strip()
        
        if not tc_name:
            break
            
        # Check if TC already exists in any region
        exists_in_other_region = False
        for r, tcs in regions.items():
            if tc_name in tcs and r != region_name:
                print(f"{Fore.RED}TC '{tc_name}' already assigned to region '{r}'.")
                if input(f"{Fore.YELLOW}Move TC from '{r}' to '{region_name}'? (y/n): ").lower() == 'y':
                    # Remove from old region
                    regions[r].remove(tc_name)
                    exists_in_other_region = False
                    region_logger.info(f"Moved TC '{tc_name}' from region '{r}' to '{region_name}'")
                else:
                    exists_in_other_region = True
                break
        
        if exists_in_other_region:
            continue
        
        # Check if TC already exists in this region
        if tc_name in regions[region_name]:
            print(f"{Fore.YELLOW}TC '{tc_name}' already assigned to this region.")
            continue
        
        # Add TC to region
        regions[region_name].append(tc_name)
        print(f"{Fore.GREEN}TC '{tc_name}' added to region '{region_name}'.")
        
    # Save changes
    if save_regions(regions):
        print(f"{Fore.GREEN}Region '{region_name}' updated successfully.")
        region_logger.info(f"Updated region '{region_name}' with new TCs")
    else:
        print(f"{Fore.RED}Failed to save changes.")

def remove_tc_from_region():
    """Remove TC from a region"""
    regions = load_regions()
    
    if not regions:
        print(f"{Fore.YELLOW}No regions defined.")
        return
    
    # Get region
    list_regions()
    selected = input(f"\n{Fore.YELLOW}Enter region number or name (0 to cancel): ")
    
    if selected == "0":
        return
        
    region_name = None
    
    # Check if input is a number
    if selected.isdigit():
        idx = int(selected) - 1
        if 0 <= idx < len(regions):
            region_name = list(regions.keys())[idx]
        else:
            print(f"{Fore.RED}Invalid region number.")
            return
    else:
        # Check if input is a region name
        if selected in regions:
            region_name = selected
        else:
            print(f"{Fore.RED}Region '{selected}' not found.")
            return
    
    # Get TCs in the region
    tcs = regions[region_name]
    
    if not tcs:
        print(f"{Fore.YELLOW}No TCs assigned to region '{region_name}'.")
        return
    
    # Print TCs for user to select
    print(f"\n{Fore.CYAN}TCs in region '{region_name}':")
    for i, tc in enumerate(tcs, 1):
        print(f"{i}. {tc}")
    
    # Get TC to remove
    selected = input(f"\n{Fore.YELLOW}Enter TC number or name to remove (0 to cancel): ")
    
    if selected == "0":
        return
    
    tc_to_remove = None
    
    # Check if input is a number
    if selected.isdigit():
        idx = int(selected) - 1
        if 0 <= idx < len(tcs):
            tc_to_remove = tcs[idx]
        else:
            print(f"{Fore.RED}Invalid TC number.")
            return
    else:
        # Check if input is a TC name
        if selected in tcs:
            tc_to_remove = selected
        else:
            print(f"{Fore.RED}TC '{selected}' not found in this region.")
            return
    
    # Confirm removal
    confirm = input(f"{Fore.YELLOW}Remove '{tc_to_remove}' from region '{region_name}'? (y/n): ").lower()
    
    if confirm != 'y':
        print(f"{Fore.YELLOW}Operation cancelled.")
        return
    
    # Remove TC
    regions[region_name].remove(tc_to_remove)
    
    # Save changes
    if save_regions(regions):
        print(f"{Fore.GREEN}TC '{tc_to_remove}' removed from region '{region_name}'.")
        region_logger.info(f"Removed TC '{tc_to_remove}' from region '{region_name}'")
    else:
        print(f"{Fore.RED}Failed to save changes.")

def rename_region():
    """Rename an existing region"""
    regions = load_regions()
    
    if not regions:
        print(f"{Fore.YELLOW}No regions defined.")
        return
    
    # Get region to rename
    list_regions()
    selected = input(f"\n{Fore.YELLOW}Enter region number or name to rename (0 to cancel): ")
    
    if selected == "0":
        return
        
    old_name = None
    
    # Check if input is a number
    if selected.isdigit():
        idx = int(selected) - 1
        if 0 <= idx < len(regions):
            old_name = list(regions.keys())[idx]
        else:
            print(f"{Fore.RED}Invalid region number.")
            return
    else:
        # Check if input is a region name
        if selected in regions:
            old_name = selected
        else:
            print(f"{Fore.RED}Region '{selected}' not found.")
            return
    
    # Get new name
    new_name = input(f"{Fore.YELLOW}Enter new name for region '{old_name}': ").strip()
    
    if not new_name:
        print(f"{Fore.RED}Region name cannot be empty.")
        return
    
    if new_name in regions:
        print(f"{Fore.RED}Region '{new_name}' already exists.")
        return
    
    # Rename region
    regions[new_name] = regions.pop(old_name)
    
    # Save changes
    if save_regions(regions):
        print(f"{Fore.GREEN}Region '{old_name}' renamed to '{new_name}'.")
        region_logger.info(f"Renamed region '{old_name}' to '{new_name}'")
    else:
        print(f"{Fore.RED}Failed to save changes.")

def delete_region():
    """Delete a region"""
    regions = load_regions()
    
    if not regions:
        print(f"{Fore.YELLOW}No regions defined.")
        return
    
    # Get region to delete
    list_regions()
    selected = input(f"\n{Fore.YELLOW}Enter region number or name to delete (0 to cancel): ")
    
    if selected == "0":
        return
        
    region_name = None
    
    # Check if input is a number
    if selected.isdigit():
        idx = int(selected) - 1
        if 0 <= idx < len(regions):
            region_name = list(regions.keys())[idx]
        else:
            print(f"{Fore.RED}Invalid region number.")
            return
    else:
        # Check if input is a region name
        if selected in regions:
            region_name = selected
        else:
            print(f"{Fore.RED}Region '{selected}' not found.")
            return
    
    # Check if region has TCs
    if regions[region_name]:
        print(f"{Fore.YELLOW}Warning: Region '{region_name}' has {len(regions[region_name])} TCs assigned.")
        print(f"{Fore.YELLOW}TCs in this region: {', '.join(regions[region_name])}")
        print(f"{Fore.YELLOW}If you delete this region, the TCs will no longer be assigned to any region.")
    
    # Confirm deletion
    confirm = input(f"{Fore.RED}Are you sure you want to delete region '{region_name}'? (yes/no): ").lower()
    
    if confirm != 'yes':
        print(f"{Fore.YELLOW}Deletion cancelled.")
        return
    
    # Delete region
    del regions[region_name]
    
    # Save changes
    if save_regions(regions):
        print(f"{Fore.GREEN}Region '{region_name}' deleted successfully.")
        region_logger.info(f"Deleted region '{region_name}'")
    else:
        print(f"{Fore.RED}Failed to save changes.")

def import_regions_from_cert_inns():
    """Auto-generate regions based on cert_inns.json"""
    try:
        # Check if cert_inns.json exists
        if not os.path.exists('cert_inns.json'):
            print(f"{Fore.RED}cert_inns.json not found.")
            return
        
        # Load cert_inns.json
        with open('cert_inns.json', 'r', encoding='utf-8') as f:
            cert_inns = json.load(f)
        
        if not cert_inns:
            print(f"{Fore.YELLOW}No data found in cert_inns.json.")
            return
        
        # Get user input for region creation
        print(f"{Fore.CYAN}This will create regions from cert_inns.json.")
        print(f"{Fore.CYAN}Available certificates with TCs:")
        
        tcs_found = 0
        for cert, tc_inn_pairs in cert_inns.items():
            tc_count = len(tc_inn_pairs)
            if tc_count > 0:
                tcs_found += tc_count
                print(f"- {cert}: {tc_count} TCs")
        
        if tcs_found == 0:
            print(f"{Fore.YELLOW}No TCs found in cert_inns.json.")
            return
        
        # Ask user to specify region structure
        print(f"\n{Fore.YELLOW}How do you want to organize regions?")
        print(f"1. One region per certificate")
        print(f"2. All in one region")
        print(f"3. Create custom regions")
        
        choice = input(f"{Fore.YELLOW}Enter your choice (1-3): ")
        
        regions = load_regions()
        
        if choice == "1":
            # Create one region per certificate
            for cert, tc_inn_pairs in cert_inns.items():
                if not tc_inn_pairs:
                    continue
                
                # Use cert name as region
                region_name = cert
                # Ensure uniqueness
                if region_name in regions:
                    region_name = f"{cert} Region"
                    if region_name in regions:
                        i = 1
                        while f"{region_name} {i}" in regions:
                            i += 1
                        region_name = f"{region_name} {i}"
                
                # Add TCs to region
                regions[region_name] = []
                for pair in tc_inn_pairs:
                    for tc in pair.keys():
                        if tc not in regions[region_name]:
                            regions[region_name].append(tc)
                
                print(f"{Fore.GREEN}Created region '{region_name}' with {len(regions[region_name])} TCs.")
        
        elif choice == "2":
            # Add all TCs to one region
            region_name = input(f"{Fore.YELLOW}Enter name for the region: ").strip()
            if not region_name:
                region_name = "All TCs"
            
            if region_name in regions:
                print(f"{Fore.YELLOW}Region '{region_name}' already exists.")
                merge = input(f"{Fore.YELLOW}Merge with existing region? (y/n): ").lower()
                if merge != 'y':
                    return
            else:
                regions[region_name] = []
            
            # Add all TCs to the region
            for cert, tc_inn_pairs in cert_inns.items():
                for pair in tc_inn_pairs:
                    for tc in pair.keys():
                        if tc not in regions[region_name]:
                            regions[region_name].append(tc)
            
            print(f"{Fore.GREEN}Added {len(regions[region_name])} TCs to region '{region_name}'.")
        
        elif choice == "3":
            # Let user create custom regions
            print(f"{Fore.CYAN}You'll need to specify which certificate goes to which region.")
            
            all_tcs = {}
            for cert, tc_inn_pairs in cert_inns.items():
                for pair in tc_inn_pairs:
                    for tc, inn in pair.items():
                        all_tcs[tc] = {"cert": cert, "inn": inn}
            
            if not all_tcs:
                print(f"{Fore.YELLOW}No TCs found.")
                return
            
            # Print all available TCs
            print(f"\n{Fore.CYAN}Available TCs:")
            for i, (tc, info) in enumerate(all_tcs.items(), 1):
                print(f"{i}. {tc} (Cert: {info['cert']}, INN: {info['inn']})")
            
            # Let user create regions
            while True:
                region_name = input(f"\n{Fore.YELLOW}Enter region name (or empty to finish): ").strip()
                if not region_name:
                    break
                
                if region_name in regions:
                    print(f"{Fore.YELLOW}Region '{region_name}' already exists.")
                    continue
                
                regions[region_name] = []
                
                # Let user add TCs to this region
                while True:
                    tc_input = input(f"{Fore.YELLOW}Enter TC number or name (or empty to finish): ").strip()
                    if not tc_input:
                        break
                    
                    # Check if input is a number
                    if tc_input.isdigit():
                        idx = int(tc_input) - 1
                        if 0 <= idx < len(all_tcs):
                            tc = list(all_tcs.keys())[idx]
                            if tc not in regions[region_name]:
                                regions[region_name].append(tc)
                                print(f"{Fore.GREEN}Added '{tc}' to region '{region_name}'.")
                            else:
                                print(f"{Fore.YELLOW}TC '{tc}' already in region '{region_name}'.")
                        else:
                            print(f"{Fore.RED}Invalid TC number.")
                    else:
                        # Check if input is a TC name
                        if tc_input in all_tcs:
                            if tc_input not in regions[region_name]:
                                regions[region_name].append(tc_input)
                                print(f"{Fore.GREEN}Added '{tc_input}' to region '{region_name}'.")
                            else:
                                print(f"{Fore.YELLOW}TC '{tc_input}' already in region '{region_name}'.")
                        else:
                            print(f"{Fore.RED}TC '{tc_input}' not found.")
        
        else:
            print(f"{Fore.RED}Invalid choice.")
            return
        
        # Save regions
        if save_regions(regions):
            print(f"{Fore.GREEN}Regions saved successfully.")
            region_logger.info(f"Imported regions from cert_inns.json")
        else:
            print(f"{Fore.RED}Failed to save regions.")
    
    except Exception as e:
        log_exception(region_logger, e, "Error importing regions from cert_inns.json")
        print(f"{Fore.RED}Error: {e}")

def manage_regions():
    """Main function to manage regions"""
    while True:
        print(f"\n{Fore.CYAN}╔══════════ УПРАВЛЕНИЕ РЕГИОНАМИ ══════════╗")
        print(f"{Fore.YELLOW}║ 1. Просмотр регионов                     ║")
        print(f"{Fore.YELLOW}║ 2. Добавить новый регион                 ║")
        print(f"{Fore.YELLOW}║ 3. Добавить ТС в регион                  ║")
        print(f"{Fore.YELLOW}║ 4. Удалить ТС из региона                 ║")
        print(f"{Fore.YELLOW}║ 5. Переименовать регион                  ║")
        print(f"{Fore.YELLOW}║ 6. Удалить регион                        ║")
        print(f"{Fore.YELLOW}║ 7. Детали региона                        ║")
        print(f"{Fore.YELLOW}║ 8. Импортировать регионы из cert_inns.json║")
        print(f"{Fore.GREEN}║ 0. ◄ Вернуться в главное меню            ║")
        print(f"{Fore.CYAN}╚═══════════════════════════════════════════╝")
        
        choice = input(f"{Fore.GREEN}Выберите пункт меню: ")
        
        if choice == '1':
            list_regions()
        elif choice == '2':
            add_region()
        elif choice == '3':
            add_tc_to_region()
        elif choice == '4':
            remove_tc_from_region()
        elif choice == '5':
            rename_region()
        elif choice == '6':
            delete_region()
        elif choice == '7':
            view_region_details()
        elif choice == '8':
            import_regions_from_cert_inns()
        elif choice == '0':
            region_logger.info("Returning to main menu")
            break
        else:
            print(f"{Fore.RED}Неверный выбор. Повторите попытку.")
        
        # Pause after each action
        input(f"\n{Fore.GREEN}Нажмите Enter для продолжения...")

if __name__ == "__main__":
    manage_regions()
