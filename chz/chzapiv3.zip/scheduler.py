import os
import time
import json
import threading
import subprocess
import sys
import atexit
from datetime import datetime, timedelta
from logger_config import get_logger, log_exception

# Set up logger
scheduler_logger = get_logger("scheduler")

class Scheduler:
    """Handles scheduling of the daily processing tasks"""
    
    def __init__(self, check_time="00:05"):
        """Initialize the scheduler
        
        Args:
            check_time (str): Time to run daily (HH:MM format, 24h)
        """
        self.logger = scheduler_logger  # Use the module-level logger
        self.check_time = check_time
        self.running = False
        self.thread = None
        
        # Parse the check time
        hour, minute = map(int, check_time.split(':'))
        self.target_hour = hour
        self.target_minute = minute
        
        self.logger.info(f"Scheduler initialized to run at {check_time} daily")
        
        # Register cleanup function to run on program exit
        atexit.register(self._cleanup)
        
    def _cleanup(self):
        """Clean up resources on program exit"""
        self.logger.info("Scheduler cleanup - ensuring background process continues")
        
        # Make sure the detached process is running
        ensure_scheduler_running(quiet=True)
        
    def _get_seconds_until_next_run(self):
        """Calculate seconds until next scheduled run"""
        now = datetime.now()
        
        # Create today's target time
        target = now.replace(
            hour=self.target_hour,
            minute=self.target_minute,
            second=0,
            microsecond=0
        )
        
        # If target time is in the past, schedule for tomorrow
        if target < now:
            target += timedelta(days=1)
            
        # Get seconds until target
        delta = target - now
        return delta.total_seconds()
        
    def _should_run_today(self):
        """Check if we need to run today based on last_run.json"""
        last_run_file = 'last_run.json'
        today = datetime.now().date()
        
        # If no last run file, we should run
        if not os.path.exists(last_run_file):
            self.logger.info("No last_run.json found, will run today")
            return True
            
        try:
            with open(last_run_file, 'r') as f:
                data = json.load(f)
                last_run = datetime.fromisoformat(data.get('last_run', ''))
                
                # If last run was on a different day, we should run
                if last_run.date() != today:
                    self.logger.info(f"Last run was on {last_run.date()}, will run today")
                    return True
                else:
                    self.logger.info(f"Already ran today ({today}), will wait until tomorrow")
                    return False
        except Exception as e:
            self.logger.error(f"Error checking last_run.json: {e}")
            return True  # Run if there's any issue reading the file
    
    def run(self):
        """Run the daily processing once"""
        from main import run_daily_process
        
        self.logger.info("Starting scheduled daily processing for yesterday's data")
        
        try:
            # Always run when scheduled, regardless of last_run.json
            # This ensures we run every day at the scheduled time
            self.logger.info("Running daily processing task (processing yesterday's data)")
            run_daily_process()
            self.logger.info("Daily processing completed successfully")
            
            # Update last run time to today
            current_time = datetime.now()
            yesterday = (current_time - timedelta(days=1)).strftime('%Y-%m-%d')
            
            with open('last_run.json', 'w') as f:
                json.dump({
                    'last_run': current_time.isoformat(),
                    'data_date': yesterday,  # Record which date's data was processed
                    'scheduler_run': True,
                    'next_scheduled_run': (current_time + timedelta(days=1)).replace(
                        hour=self.target_hour, minute=self.target_minute, second=0
                    ).isoformat()
                }, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Error during daily processing: {e}")
    
    def run_continuously(self):
        """Run the scheduler in a loop"""
        self.running = True
        self.logger.info("Scheduler continuous mode started")
        
        # Write PID file to indicate scheduler is running
        try:
            with open('scheduler.pid', 'w') as f:
                f.write(str(os.getpid()))
            self.logger.info(f"Scheduler running with PID {os.getpid()}")
        except Exception as e:
            self.logger.error(f"Failed to write PID file: {e}")
        
        # First check if we need to run today 
        if self._should_run_today():
            self.logger.info("Running initial process...")
            self.run()
        
        # Continue running indefinitely
        while self.running:
            try:
                # Calculate time until next run
                seconds_to_wait = self._get_seconds_until_next_run()
                next_run = datetime.now() + timedelta(seconds=seconds_to_wait)
                
                self.logger.info(f"Next scheduled run at {next_run.strftime('%Y-%m-%d %H:%M:%S')} "
                                f"({seconds_to_wait/3600:.1f} hours from now)")
                
                # Wait until scheduled time
                # Break waiting into smaller intervals to allow graceful shutdown
                wait_interval = 60  # Check every minute if we should continue
                while seconds_to_wait > 0 and self.running:
                    time.sleep(min(wait_interval, seconds_to_wait))
                    seconds_to_wait -= wait_interval
                
                # Run the task if still running
                if self.running:
                    self.run()
            except Exception as e:
                self.logger.error(f"Error in scheduler loop: {e}")
                # Wait a bit before retrying
                time.sleep(300)
    
    def start_background(self):
        """Start the scheduler in a background thread"""
        if self.thread is not None and self.thread.is_alive():
            self.logger.warning("Scheduler already running in background")
            return self.thread
            
        # Use non-daemon thread so it continues if main thread exits
        self.thread = threading.Thread(target=self.run_continuously, daemon=False)
        self.thread.start()
        self.logger.info("Scheduler started in background thread")
        return self.thread
    
    def start_detached(self):
        """Start scheduler as a completely detached process that continues after main program exits"""
        # Get the path to the current Python executable and script
        python_exe = sys.executable
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
        
        # Create a new process that will run even after the parent exits
        try:
            if os.name == 'nt':  # Windows
                # Use subprocess.DETACHED_PROCESS on Windows to detach from console
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0  # SW_HIDE
                
                process = subprocess.Popen(
                    [python_exe, script_path, "--scheduler"],
                    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                    close_fds=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    startupinfo=startupinfo
                )
                
            else:  # Linux/Mac
                process = subprocess.Popen(
                    [python_exe, script_path, "--scheduler"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                    start_new_session=True
                )
                
            # Wait a moment to ensure process started
            time.sleep(1)
            self.logger.info(f"Started scheduler in detached process with PID {process.pid}")
            return process.pid
        except Exception as e:
            self.logger.error(f"Failed to start detached scheduler: {e}")
            return None
        
    def stop(self):
        """Stop the scheduler"""
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(1.0)  # Give it 1 second to finish
            self.logger.info("Scheduler stopped")

def ensure_scheduler_running(quiet=False):
    """
    Ensure that the scheduler is running. If not, start it.
    This function is called on program startup.
    
    Args:
        quiet (bool): If True, suppress most logging
    """
    logger = scheduler_logger  # Use the module-level logger
    
    if not quiet:
        logger.info("Checking if scheduler is running...")
    
    # Check if the scheduler is already running by looking for a scheduler PID file
    pid_file = "scheduler.pid"
    
    if os.path.exists(pid_file):
        try:
            with open(pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            # Try to check if the process with this PID exists
            process_exists = False
            
            if os.name == 'nt':  # Windows
                try:
                    # On Windows, check using tasklist
                    subprocess.check_output(f'tasklist /FI "PID eq {pid}" /NH', shell=True)
                    process_exists = str(pid) in str(subprocess.check_output(f'tasklist /FI "PID eq {pid}" /NH', shell=True))
                except:
                    process_exists = False
            else:  # Linux/Mac
                try:
                    os.kill(pid, 0)  # This will raise an exception if the process doesn't exist
                    process_exists = True
                except OSError:
                    process_exists = False
            
            if process_exists:
                if not quiet:
                    logger.info(f"Scheduler already running with PID {pid}")
                return pid
        except:
            # Any error means we should start a new scheduler
            pass
    
    if not quiet:
        logger.info("Starting scheduler as detached process")
    
    # Create a new process that will run independently
    scheduler = Scheduler()
    pid = scheduler.start_detached()
    
    if pid:
        if not quiet:
            logger.info(f"Scheduler started successfully with PID {pid}")
        return pid
    else:
        logger.error("Failed to start scheduler in background")
        return None

def run_daily_process(self):
    """Run the daily data processing"""
    try:
        subprocess.run([sys.executable, "main.py", "--daily-run"], check=True)
        scheduler_logger.info("Daily processing completed successfully")
        
        # Explicitly send consolidated reports by region
        scheduler_logger.info("Sending consolidated region reports...")
        try:
            from send_daily_report import process_and_send_reports
            process_and_send_reports()
            scheduler_logger.info("Regional email reports sent successfully")
        except Exception as e:
            log_exception(scheduler_logger, e, "Error sending regional reports")
            
        return True
        
    except subprocess.CalledProcessError as e:
        scheduler_logger.error(f"Daily processing failed with exit code {e.returncode}")
        return False
    except Exception as e:
        log_exception(scheduler_logger, e, "Error running daily processing")
        return False

if __name__ == "__main__":
    # When run directly, ensure the scheduler is running
    ensure_scheduler_running()
