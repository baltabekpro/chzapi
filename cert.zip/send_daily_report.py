import json
import os
import glob
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from logger_config import get_logger, log_exception

# Импортируем менеджер регионов
from region_manager import RegionManager

# Initialize logger
email_logger = get_logger("email")

def load_email_config():
    """Load email configuration from file"""
    try:
        with open('email_config.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        email_logger.error("Email configuration file not found")
        return None
    except Exception as e:
        log_exception(email_logger, e, "Error loading email config")
        return None

def load_reports_for_date(date_str=None):
    """Load violation reports for specific date"""
    if date_str is None:
        # Default to yesterday
        date_str = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    reports = {}
    output_dir = 'output'
    
    # Find all JSON violation reports for specified date
    for cert_dir in os.listdir(output_dir):
        cert_path = os.path.join(output_dir, cert_dir)
        
        if os.path.isdir(cert_path):
            # Look for violation report JSON files
            report_pattern = os.path.join(cert_path, f'violations_{date_str}.json')
            matching_reports = glob.glob(report_pattern)
            
            if matching_reports:
                try:
                    with open(matching_reports[0], 'r', encoding='utf-8') as f:
                        report_data = json.load(f)
                        reports[cert_dir] = report_data
                except Exception as e:
                    log_exception(email_logger, e, f"Error loading report for {cert_dir}")
    
    return reports, date_str

def group_reports_by_region(reports):
    """Group reports by region based on TS in cert names"""
    region_manager = RegionManager()
    grouped_reports = {}
    
    # Create an "Other" region for unassigned TS
    grouped_reports["Другие"] = {
        "violations": {},
        "ts_reports": {}
    }
    
    for cert_name, report_data in reports.items():
        # Извлекаем ТС из имени сертификата (обычно формат "Имя - ТС")
        ts = None
        if " - " in cert_name:
            ts = cert_name.split(" - ")[1].strip()
        else:
            # Используем сам сертификат как ТС для поиска (на случай если имя сертификата совпадает с ТС)
            ts = cert_name
        
        # Находим регион для данной ТС
        region = region_manager.get_region_for_ts(ts)
        
        if region:
            region_name = region.get('name')
            
            # Инициализируем данные региона если это первая запись
            if region_name not in grouped_reports:
                grouped_reports[region_name] = {
                    "violations": {},
                    "ts_reports": {},
                    "email": region.get('email')
                }
            
            # Добавляем отчет ТС в регион
            grouped_reports[region_name]["ts_reports"][ts] = report_data
            
            # Аггрегируем нарушения по товарным группам для региона
            for group, count in report_data.get('violations', {}).items():
                if group in grouped_reports[region_name]["violations"]:
                    grouped_reports[region_name]["violations"][group] += count
                else:
                    grouped_reports[region_name]["violations"][group] = count
        else:
            # Добавляем в регион "Другие", если не нашли регион для ТС
            grouped_reports["Другие"]["ts_reports"][ts] = report_data
            
            # Аггрегируем нарушения по товарным группам для региона "Другие"
            for group, count in report_data.get('violations', {}).items():
                if group in grouped_reports["Другие"]["violations"]:
                    grouped_reports["Другие"]["violations"][group] += count
                else:
                    grouped_reports["Другие"]["violations"][group] = count
    
    # Удаляем пустой регион "Другие", если все ТС были распределены
    if not grouped_reports["Другие"]["ts_reports"]:
        del grouped_reports["Другие"]
    
    return grouped_reports

def create_html_report_for_region(region_name, region_data, date_str):
    """Create HTML report for region with TS breakdown"""
    total_violations = sum(region_data.get('violations', {}).values())
    
    html = f"""
    <h2>Отчет о нарушениях маркировки за {date_str} - Регион: {region_name}</h2>
    <p>Общее количество нарушений в регионе: {total_violations}</p>
    """
    
    # Add section for each TS in this region
    for ts, ts_data in region_data.get('ts_reports', {}).items():
        ts_violations = ts_data.get('violations', {})
        ts_total = sum(ts_violations.values())
        
        html += f"""
        <h3>Торговая сеть: {ts}</h3>
        <table border="1" style="border-collapse: collapse; width: 100%;">
            <tr style="background-color: #f2f2f2;">
                <th style="padding: 8px;">Товарная группа</th>
                <th style="padding: 8px;">Количество нарушений</th>
            </tr>
        """
        
        for group, count in sorted(ts_violations.items()):
            html += f"""
            <tr>
                <td style="padding: 8px;">{group}</td>
                <td style="padding: 8px; text-align: center;">{count}</td>
            </tr>
            """
        
        html += f"""
            <tr style="background-color: #f2f2f2; font-weight: bold;">
                <td style="padding: 8px;">Всего нарушений:</td>
                <td style="padding: 8px; text-align: center;">{ts_total}</td>
            </tr>
        </table>
        """
    
    return html

def send_email_report(recipient, subject, html_content, config):
    """Send email with HTML content"""
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = config['sender_email']
        msg['To'] = recipient
        
        # Attach HTML content
        msg.attach(MIMEText(html_content, 'html'))
        
        # Connect to SMTP server and send email
        with smtplib.SMTP(config['smtp_server'], config['smtp_port']) as server:
            server.starttls()
            server.login(config['sender_email'], config['sender_password'])
            server.send_message(msg)
            
        email_logger.info(f"Email sent to {recipient}: {subject}")
        return True
    except Exception as e:
        log_exception(email_logger, e, f"Error sending email to {recipient}")
        return False

def send_daily_reports(date_str=None, manual_run=False):
    """Send daily reports for all regions"""
    try:
        # Load email configuration
        email_config = load_email_config()
        if not email_config:
            email_logger.error("Email configuration not loaded, cannot send reports")
            return False
            
        # Load reports for specified date
        reports, report_date = load_reports_for_date(date_str)
        
        if not reports:
            email_logger.warning(f"No reports found for date {report_date}")
            return False
            
        email_logger.info(f"Sending daily reports for {report_date}, found {len(reports)} reports")
        
        # Group reports by region
        grouped_reports = group_reports_by_region(reports)
        
        # Send report for each region
        for region_name, region_data in grouped_reports.items():
            # Create HTML report for this region
            html_content = create_html_report_for_region(region_name, region_data, report_date)
            
            # Determine recipients
            recipients = []
            
            # Add region-specific email if configured
            region_email = region_data.get('email')
            if region_email:
                recipients.append(region_email)
            
            # Add default recipients from config
            recipients.extend(email_config.get('recipient_emails', []))
            
            # Ensure we have unique recipients
            recipients = list(set(recipients))
            
            if not recipients:
                email_logger.warning(f"No recipients configured for region {region_name}")
                continue
                
            # Prepare subject line
            subject = f"Отчет о нарушениях маркировки - Регион: {region_name} - {report_date}"
            
            # Send to each recipient
            for recipient in recipients:
                send_email_report(recipient, subject, html_content, email_config)
                
        # Update last email run timestamp
        with open('last_email_run.json', 'w', encoding='utf-8') as f:
            json.dump({
                'last_run': datetime.now().isoformat(),
                'manual_run': manual_run
            }, f, ensure_ascii=False, indent=2)
            
        email_logger.info(f"Daily reports sent for {len(grouped_reports)} regions")
        return True
        
    except Exception as e:
        log_exception(email_logger, e, "Error sending daily reports")
        return False

# Add an alias for compatibility with existing code
send_consolidated_reports = send_daily_reports
# Add another alias needed by main.py
process_and_send_reports = send_daily_reports

if __name__ == "__main__":
    # If run directly, send reports for yesterday
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    send_daily_reports(yesterday, manual_run=True)
